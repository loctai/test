function randomly(tree, value) {
  if (!tree)
    return { value };

  const {
    left,
    right,
    ...rest
  } = tree;
  const shouldGoLeft = Math.random() >= 0.5;
  console.log('left', left, 'right', right);
  if (!left || shouldGoLeft) return {
    ...rest,
    left: randomly(left, value),
    right
  };
  return {
    ...rest,
    left,
    right: randomly(right, value),
  };
}

function levelOrder(tree, value) {
  console.log('tree', tree)
  if (!tree)
    return { value };
    const {
      left,
      right,
      ...rest
    } = tree;
  //TODO: Task 1
  return randomly(tree, value);
}

function binarySearchTree(tree, value) {
  //TODO: Task 2
  return randomly(tree, value);
}

export {
  randomly,
  levelOrder,
  binarySearchTree,
};
